package com.example.pavankalyanyalamati.pill_remainder;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.provider.AlarmClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class Remainder extends AppCompatActivity {
    private AlarmManager alarmMgr;
    private PendingIntent alarmIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remainder);
        Button btn = (Button)findViewById(R.id.btn);
        final EditText nam1 = (EditText)findViewById(R.id.name1);
        final EditText tim1 = (EditText)findViewById(R.id.time1);
        final EditText tim11= (EditText)findViewById(R.id.time11);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n1,e;
                int t1,t11;
                n1=nam1.getText().toString();
                t1= Integer.parseInt(tim1.getText().toString());
                t11=Integer.parseInt(tim11.getText().toString());
                if(n1.equals("")&&t1==0) {
                    Toast t = Toast.makeText(Remainder.this, "enter tablet name or check time", Toast.LENGTH_SHORT);
                    t.show();
                }
                else
                {
                    Toast t= Toast.makeText(Remainder.this,"Reminder has been created",Toast.LENGTH_SHORT);
                    t.show();
                    Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
                    i.putExtra(AlarmClock.EXTRA_MESSAGE,n1);
                    i.putExtra(AlarmClock.EXTRA_HOUR, t1);
                    i.putExtra(AlarmClock.EXTRA_MINUTES, t11);
                    i.putExtra(AlarmClock.EXTRA_VIBRATE,true);
                    startActivity(i);

                    finish();

                }
            }
        });


    }
}
