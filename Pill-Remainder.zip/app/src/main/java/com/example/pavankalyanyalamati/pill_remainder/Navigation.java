package com.example.pavankalyanyalamati.pill_remainder;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;

public class Navigation extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);
        ImageView ondoc = (ImageView) findViewById(R.id.onlinedoc);
        ImageView onme = (ImageView)findViewById(R.id.onlineme);
        ImageView stone = (ImageView)findViewById(R.id.storenear);
        ImageView docne = (ImageView)findViewById(R.id.docnear);
        ImageView rays = (ImageView)findViewById(R.id.xrays);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        ondoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWeb(v);
            }
        });
        onme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWeb1(v);
            }
        });
        rays.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWeb2(v);
            }
        });
        stone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri gmmIntentUri = Uri.parse("geo:0,0?q=medicalshops");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        docne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri gmmIntentUri = Uri.parse("geo:0,0?q=Doctors");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Report had sent", Snackbar.LENGTH_SHORT)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.navigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_Logout)
        {
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            Intent Intent3=new   Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            startActivity(Intent3);
        } else if (id == R.id.reminder) {
            Intent i = new Intent(Navigation.this,Remainder.class);
            startActivity(i);

        } else if (id == R.id.profile) {


        } else if (id == R.id.aboutus) {
            Intent i = new Intent(Navigation.this,aboutus.class);
            startActivity(i);

        } else if (id == R.id.nav_share) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("message/rfc822");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"enter mail"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Share");
            intent.putExtra(Intent.EXTRA_TEXT, "Download the app");
            startActivity(Intent.createChooser(intent,"Choose App"));

        } else if (id == R.id.nav_send) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("message/rfc822");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"pavankalyanyalamati@gmail.com"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Report");
            intent.putExtra(Intent.EXTRA_TEXT, "Your app had been ropted due to the present error");
            intent.setPackage("com.google.android.gm");
            startActivity(Intent.createChooser(intent,"Choose Mail App"));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void openWeb(View view)
    {
        String s= "https://www.practo.com/consult";
        Uri uri=Uri.parse(s);

        Intent intent= new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);
    }
    public void openWeb1(View view)
    {
        String s= "https://m.medlife.com/#/root/login/LoginLandingOld";
        Uri uri=Uri.parse(s);

        Intent intent= new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);
    }
    public void openWeb2(View view)
    {
        String s= "https://www.practo.com/tests/search?city=hyderabad&lat=16.4488216&lng=80.61732119999999";
        Uri uri=Uri.parse(s);

        Intent intent= new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);
    }

}
