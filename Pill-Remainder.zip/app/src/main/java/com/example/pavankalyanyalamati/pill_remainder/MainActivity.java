package com.example.pavankalyanyalamati.pill_remainder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public Button Log;
    public Button reg;
    public EditText un,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log = (Button)findViewById(R.id.login);
        reg = (Button)findViewById(R.id.reg);
        un = (EditText)findViewById(R.id.etu);
        pass  =(EditText)findViewById(R.id.etpass);
        Log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usr,ps;
                usr=un.getText().toString();
                ps=pass.getText().toString();
                if(usr.equals(""))
                {
                    Toast t = Toast.makeText(MainActivity.this,"Enter User Name",Toast.LENGTH_SHORT);
                    t.show();
                }
                else if(ps.equals(""))
                {
                    Toast t =Toast.makeText(MainActivity.this,"Enter Password",Toast.LENGTH_SHORT);
                    t.show();
                }
                else
                {
                    Intent i = new Intent(MainActivity.this,Navigation.class);
                    startActivity(i);
                }

            }
        });
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this,Register.class);
                startActivity(in);
            }
        });
    }
}
